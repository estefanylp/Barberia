import React from 'react';
import Menu from './menu';


const Inicio = () => {
  return (
    <section>
        <Menu/>
            <section className='slider'>
                <section><img src='./src/assets/Slider/SliderUno.jpg'></img></section>
            </section>
    </section>
    
  );
};

export default Inicio;