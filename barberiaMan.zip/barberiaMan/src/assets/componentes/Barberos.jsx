import React, { useState } from 'react';
import Menu from './Menu';

const Barberos = ({ onAdd }) => {
  const [ nombre, setNombre] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    onAdd({ nombre });
    setNombre('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <label htmlFor="name">Nombre:</label>
      <input
        type="text"
        value={nombre}
        onChange={(event) => setNombre(event.target.value)}
      />
      <button type="submit">Agregar</button>
    </form>
  );
};

const BarberoCard = ({ nombre }) => {
  return (
    <section>
      <h3>{nombre}</h3>
    </section>
  );
};

const addBarberos = () => {
  const [barberList, setBarberList] = useState([]);

  const handleAddBarber = (barber) => {
    setBarberList((prevList) => [...prevList, barber]);
  };

  return (
    <section>
        <Menu/>
      <h1>Barberos</h1>
	  
      <Barbero onAdd={handleAddBarber} />
      <section>
        {barberList.map((barber, index) => (
          <BarberCard key={index} nombre    ={barber.nombre} />
        ))}
      </section>
    </section>
  );
};

export default Barberos;