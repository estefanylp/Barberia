import { Link } from 'react-router-dom';
const Menu = () => {

   

    return (
        <section className='menu'>
            <section className="foto">
                
            </section>
            <section className='opciones'>
            <button className="enlaces">clientes</button>
            <button className="enlaces">barberos</button>
            <button className="enlaces">productos</button>
            </section>
            
        </section >
    );
};

export default Menu;