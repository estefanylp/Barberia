import React from 'react';
import { Link } from 'react-router-dom';

const Menu = () => {
  return (
    <section className='contenedorMenu'>
        
      <h1 className='logo'>Barbería Man Cut</h1>
      <nav>
        <ul className='menuLink'>
          <li>
            <Link to="/producto">Productos</Link>
          </li>
          <li>
            <Link to="/cliente">Clientes</Link>
          </li>
          <li>
            <Link to="/barberos">Barberos</Link>
          </li>
        </ul>
      </nav>
    </section>
  );
};

export default Menu;