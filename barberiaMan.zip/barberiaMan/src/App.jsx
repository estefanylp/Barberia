import './App.css'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import Producto from './assets/componentes/producto'
import Cliente from './assets/componentes/Cliente'
import Barberos from './assets/componentes/Barberos'

const router = createBrowserRouter ([

  {
    path: '/',
    element: <Inicio/>
  },
  {
    path: '/producto',
    element: <Producto/>

  },
  {
    path: '/cliente',
    element: <Cliente/>
  },
  {
    path: '/barberos',
    element: <Barberos/>
  }
])

function App() {
  return(
    <div className='App'>
      <RouterProvider router={router}/>
    </div>
  )
}

export default App