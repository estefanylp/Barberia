// import Contenido from "./assets/componentes/contenido";
// import Menu from "./assets/componentes/menu";
// import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import './App.css'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import PantallaPrincipal from './PantallaPrincipal'
import Producto from './Producto'
import Cliente from './Cliente'
import Barberos from './barberos'

const router = createBrowserRouter ([

  {
    path: '/',
    element: <PantallaPrincipal/>
  },
  {
    path: '/producto',
    element: <Producto/>

  },
  {
    path: '/cliente',
    element: <Cliente/>
  },
  {
    path: '/barberos',
    element: <Barberos/>
  }
])

function App() {
  return(
    <div className='App'>
      <RouterProvider router={router}/>
    </div>
  )
}

export default App