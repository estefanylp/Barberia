const Producto = () => {



	return (
		<div className="contenido">
			<section className="agregar">

			</section>
			<section className="tarjetas">



				<form class="formulario" >
					<label>
                    <h1 className="titulo">Productos</h1>
						<p>nombre:</p>
						<input type="text" name="name" />
					</label>
					<label>
						<p>Documento:</p>
						<input type="text" name="documento" />
					</label>
					<label>
						<p>Celular:</p>
						<input type="text" name="celular" />
					</label>
					<label>
						<p>direccion:</p>
						<input type="text" name="direccion" />
					</label>
					<label>
						<p>email:</p>
						<input type="text" name="email" />
					</label>
					<input class="button" type="submit" value="Agregar" />
				</form>



			</section>


		</div>
	);
};
export default Producto;