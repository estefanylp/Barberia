import Barbero from "./Barberos.jsx"
import Cliente from "./Cliente.jsx"
import Producto from "./producto.jsx"


const Contenido = () => {



    return (
        <div className="content">


            <Barbero />
            <Cliente />
            <Producto />
        </div>
    )
}

export default Contenido;