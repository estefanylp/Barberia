const Barberos = () => {



	return (
		<div className="contenido">
			<section className="agregar">

			</section>
			<section className="tarjetas">



				<form class="formulario" >
					<h1 className="titulo">Barbero</h1>
					<label>
						<p>Nombre:</p>
						<input type="text" name="name" />
					</label>
					<label>
						<p>Documento:</p>
						<input type="text" name="documento" />
					</label>
					<label>
						<p>Celular:</p>
						<input type="text" name="celular" />
					</label>
					<label>
						<p>direccion:</p>
						<input type="text" name="direccion" />
					</label>
					<label>
						<p>E-mail:</p>
						<input type="text" name="email" />
					</label>
					<input class="button" type="button" value="Agregar" />
				</form>



			</section>


		</div>
	);
};

export default Barberos;